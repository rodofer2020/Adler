"""
alderpy.

A code to compute the Adler function.
"""

__version__ = "0.1.2"
__author__ = 'Rodolfo F'